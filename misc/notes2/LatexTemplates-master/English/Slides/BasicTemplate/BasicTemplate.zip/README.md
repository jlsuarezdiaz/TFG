# Presentación para CAEPIA 2015

La presentación trata las siguientes ideas:

## Motivación

### Problema de la diversidad de la población

- Nuestro trabajo surge a raíz de este problema.
- Una población es diversa si los individuos que la componen son diferentes entre sí.
- Se formaliza como la media de las distancias entre todas las parejas de cromosomas.
- La imagen muestra cómo evoluciona la diversidad en función del tiempo para una ejecución de un algoritmo genético generacional con elitismo sobre una instancia del viajante de comercio.
    + 
